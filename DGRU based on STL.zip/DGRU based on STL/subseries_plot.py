#encoding=utf-8
import util
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from statsmodels.tsa.seasonal import seasonal_decompose


ts, data = util.load_data("./data/IoTdata6.csv", columnName="Mem")
    
# ts1, trend = util.load_data("./data/288/sub2.csv", columnName="trend")
# ts2, seasonal = util.load_data("./data/288/sub2.csv", columnName="seasonal")
# ts3, residual = util.load_data("./data/288/sub2.csv", columnName="remainder")
    
ts1, trend = util.load_data("./data/sub6.csv", columnName="trend")
ts2, seasonal = util.load_data("data/sub6.csv", columnName="seasonal")
ts3, residual = util.load_data("data/sub6.csv", columnName="remainder")



print(trend)
print(seasonal)
print(residual)

print("seasonal ts:", len(seasonal))
print("residual ts:", len(residual))
print("trend ts:", len(trend))


# 作图观察
fig = plt.figure(dpi=300)

   
ax1 = fig.add_subplot(411)
ax2 = fig.add_subplot(412)
ax3 = fig.add_subplot(413)
ax4 = fig.add_subplot(414)

ax1.plot(data[-3000:], 'blue',linewidth=1)
ax1.set_ylabel("Original")
ax2.plot(trend[-3000:], 'blue',linewidth=1)
ax2.set_ylabel("Trend")
ax3.plot(seasonal[-3000:], 'blue',linewidth=1)
ax3.set_ylabel("Seasonality")
ax4.plot(residual[-3000:], 'blue',linewidth=1)
ax4.set_ylabel("Residual")

fig.tight_layout()

plt.show()