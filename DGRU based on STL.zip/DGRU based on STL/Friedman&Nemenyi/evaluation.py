# -*- coding: utf-8 -*-
"""
Created on Mon Jul 22 13:28:13 2019

@author: liuxin
"""

import numpy as np
import matplotlib.pyplot as plt
#from regression import linear_scores, ridge_scores, lasso_scores, elasticNet_scores

"""
    构造降序排序矩阵
"""
def rank_matrix(matrix):
    cnum = matrix.shape[1]
    rnum = matrix.shape[0]
    ## 升序排序索引
    sorts = np.argsort(matrix)
    for i in range(rnum):
        k = 1
        n = 0
        flag = False
        nsum = 0
        for j in range(cnum):
            n = n+1
            ## 相同排名评分序值
            if j < 3 and matrix[i, sorts[i,j]] == matrix[i, sorts[i,j + 1]]:
                flag = True;
                k = k + 1;
                nsum += j + 1;
            elif (j == 3 or (j < 3 and matrix[i, sorts[i,j]] != matrix[i, sorts[i,j + 1]])) and flag:
                nsum += j + 1
                flag = False;
                for q in range(k):
                    matrix[i,sorts[i,j - k + q + 1]] = nsum / k
                k = 1
                flag = False
                nsum = 0
            else:
                matrix[i, sorts[i,j]] = j + 1
                continue
            
    print (matrix)
    return matrix

"""
    Friedman检验
    参数：数据集个数n, 算法种数k, 排序矩阵rank_matrix(k x n)
    函数返回检验结果（对应于排序矩阵列顺序的一维数组）
"""
def friedman(n, k, rank_matrix):
    # 计算每一列的排序和
    sumr = sum(list(map(lambda x: np.mean(x) ** 2, rank_matrix.T)))
    #print ('sumr=',sumr)
    result = 12 * n / (k * ( k + 1)) * (sumr - k * (k + 1) ** 2 / 4)
    result = (n - 1) * result /(n * (k - 1) - result)
   # print ("Friedman=",result)
    return result

"""
    Nemenyi检验
    参数：数据集个数n, 算法种数k, 排序矩阵rank_matrix(k x n)
    函数返回CD值
"""

def nemenyi(n, k, q):
    return q * (np.sqrt(k * (k + 1) / (6 * n)))

# 输入每个算法的性能指标在三个数据集上的平均值（30次）
############  MAE ############
# ARIMA = [0.3811,0.7523,0.5815]
# SVR = [0.2760,0.5716,0.4495]
# MLP = [0.2725,0.5751,0.4633]   
# LSTM = [0.2699,0.5704,0.4624]
# GRU = [0.2550,0.5159,0.3969]

# DSVR = [0.2280,0.4669,0.3560]
# DMLP = [0.2241,0.4564,0.3872]
# MLPLSTM = [0.2256,0.4576,0.3812]
# MLPGRU = [0.2187,0.4508,0.3534]
# DLSTM = [0.2190,0.4220,0.3548]
# LSTMGRU = [0.2169,0.3966,0.3378]
# DGRU = [0.2148,0.3816,0.3306]
#############################
############ RMSE ############
# ARIMA = [0.5888,1.0789,1.0537]
# SVR = [0.3966,0.8033,0.6385]
# MLP = [0.4010,0.8087,0.6770]   
# LSTM = [0.4053,0.8092,0.6761]
# GRU = [0.3875,0.7306,0.6085]


# DSVR = [0.3711,0.6633,0.5716]
# DMLP = [0.3636,0.6550,0.5979]
# MLPLSTM = [0.3681,0.6647,0.5983]
# MLPGRU = [0.3584,0.6458,0.5518]
# DLSTM = [0.3671,0.6116,0.5698]
# LSTMGRU = [0.3577,0.5809,0.5365]
# DGRU = [0.3561,0.5567,0.5280]
# #############################

# ############  MAPE ############
ARIMA = [0.4192,1.1761,1.3486]
SVR = [0.3033,0.9010,1.0647]
MLP = [0.2995,0.8981,1.0971]   
LSTM = [0.2969,0.8915,1.1002]
GRU = [0.2805,0.8091,0.9375]

DSVR = [0.2512,0.7343,0.8387]
DMLP = [0.2468,0.7131,0.9163]
MLPLSTM = [0.2485,0.7158,0.9042]
MLPGRU = [0.2410,0.7039,0.8335]
DLSTM = [0.2415,0.6615,0.8421]
LSTMGRU = [0.2391,0.6197,0.7974]
DGRU = [0.2368,0.5956,0.7786]

#############################


matrix = np.array([ARIMA,SVR, MLP, LSTM, GRU, DSVR, DMLP, MLPLSTM, MLPGRU, DLSTM, LSTMGRU, DGRU])
#print (matrix)
matrix_r = rank_matrix(matrix.T)
Friedman = friedman(3, 12, matrix_r)


print ("Friedman=",Friedman)

CD = nemenyi(3, 12, 2.569)#2.569需要定义
print ('CD=', CD)

##画CD图
rank_x = list(map(lambda x: np.mean(x), matrix))

name_y = ["ARIMA","SVR", "MLP", "LSTM", "GRU",'DSVR','DMLP',"MLPLSTM", 
          'MLPGRU','DLSTM','LSTMGRU','DGRU']
min_ = [x for x in rank_x - CD/2]
max_ = [x for x in rank_x + CD/2]

plt.title("Friedman")
plt.scatter(rank_x,name_y)
plt.hlines(name_y,min_,max_)

print (rank_x)