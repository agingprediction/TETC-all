from pandas import read_csv
from matplotlib import pyplot as plt
from statsmodels.tsa.arima.model import ARIMA
from sklearn.metrics import mean_squared_error
from math import sqrt
import numpy as np
import numpy
from sklearn.metrics import mean_squared_error, mean_absolute_error
import warnings
warnings.simplefilter("ignore")
def predict(coef, history):
	yhat = 0.0
	for i in range(1, len(coef)+1):
		yhat += coef[i-1] * history[-i]
	return yhat
#差分
def difference(dataset):
	diff = list()
	for i in range(1, len(dataset)):
		value = dataset[i] - dataset[i - 1]
		diff.append(value)
	return numpy.array(diff)

series = read_csv('./data/IoTdata3.csv', header=0, index_col=0, error_bad_lines=False).tail(1728).reset_index(drop= True)
# series = read_csv('./data/IoTdata2.csv', header=0, index_col=0, error_bad_lines=False).tail(2880).reset_index(drop= True)
# series = read_csv('./data/IoTdata3.csv', header=0, index_col=0, error_bad_lines=False).tail(1728).reset_index(drop= True)


X = series['Mem'].tolist()
size = int(len(X)*0.7)# 不为整数，自己指定具体整数

#size=1209#1209
train, test = X[0:size], X[size:]
history = [x for x in train]
predictions = list()
for t in range(len(test)):
    #  p = 3,2,2
    #  q = 3,3,3  d=0
	model = ARIMA(history, order=(2,0,3))
    
	model_fit = model.fit()
	ar_coef, ma_coef = model_fit.arparams, model_fit.maparams
	resid = model_fit.resid
	diff = difference(history)
	yhat = history[-1] + predict(ar_coef, diff) + predict(ma_coef, resid)
	predictions.append(yhat)
	obs = test[t]
	history.append(obs)
	print('>predicted=%.6f, expected=%.6f' % (yhat, obs))
mae = mean_absolute_error(test, predictions)

rmse = sqrt(mean_squared_error(test, predictions))
#mape = sum(np.abs((test-predictions)/test))/len(test)*100

def mean_absolute_percentage_error(y_true, y_pred):
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    return np.mean(np.abs((y_true - y_pred) / y_true)) * 100


print('Test MAE: %.6f' % mae)
print('Test RMSE: %.6f' % rmse)
print('Test MAPE:%.6f'% mean_absolute_percentage_error(np.array(test), predictions))
#print('Test MAPE: %.3f' % mape)
plt.plot(X, label="Reference", color='green')
plt.plot(range(len(train),len(train)+519),predictions, color='red',label='arima_test_Prediction')#865/865/519/778
plt.title('Prediction', size=12)
plt.legend()
#plt.savefig('./data/pic/arima.jpg')
plt.show()

