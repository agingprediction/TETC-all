#encoding=utf-8

import numpy as np
import util
from models import decompose
import eval
from naive_RNN_forecasting import RNN_forecasting
import time
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
import naive_MLP_forecasting as ANNFORECAST



def decompose_MLP_forecasting(ts, ts1, ts2, ts3, data, trend, seasonal, redidual, freq, lag, epoch=20, hidden_num=64,
                              batch_size=32, lr=1e-3, unit="GRU", varFlag=False, maxLen=48, minLen=24, step=8):


    print("trend shape:", trend.shape)
    print("peroid shape:", seasonal.shape)
    print("residual shape:", residual.shape)


    print("trend shape:", trend.shape)
    print("peroid shape:", seasonal.shape)
    print("residual shape:", residual.shape)
    
    # 分别预测
    resWin = trendWin = lag
    t1 = time.time()
    trTrain, trTest, mae1, mrse1, smape1 = \
        ANNFORECAST.MLP_forecasting(trend, inputDim=trendWin, epoch=epoch, hiddenNum=hidden_num,
                                    batchSize=batch_size, lr=lr)
    resTrain, resTest, mae2, mrse2, smape2 = \
        ANNFORECAST.MLP_forecasting(residual, inputDim=trendWin, epoch=epoch, hiddenNum=hidden_num,
                                    batchSize=batch_size, lr=lr)
    t2 = time.time()
    print("time:", t2-t1)

    # 数据对齐
    trendPred, resPred = util.align(trTrain, trTest, trendWin, resTrain, resTest, resWin)
    print("trendPred shape is", trendPred.shape)
    print("resPred shape is", resPred.shape)

    # 获取最终预测结果
    #finalPred = trendPred + seasonal + resPred

    trainPred = trTrain + seasonal[trendWin:trendWin+trTrain.shape[0]] + resTrain
    testPred = trTest + seasonal[2 * resWin + resTrain.shape[0]:] + resTest
    

    # 获得ground-truth数据
    data = data[:]
    trainY = data[trendWin:trendWin+trTrain.shape[0]]
    testY = data[2 * resWin+resTrain.shape[0]:]
    
       #trend子序列的原始序列长度（去除lag）
    trTrainY = trend[trendWin:trendWin+trTrain.shape[0]]
    trTestY = trend[2*trendWin+trTrain.shape[0]:]
    
    #residual子序列的原始序列长度（去除lag）
    resTrainY = residual[trendWin:trendWin+trTrain.shape[0]]
    resTestY = residual[2*trendWin+trTrain.shape[0]:]

    # 评估指标
    MAE = eval.calcMAE(testY, testPred)
    print(MAE)
    MRSE = eval.calcRMSE(testY, testPred)
    print( MRSE)
    MAPE = eval.calcMAPE(testY, testPred)
    print(MAPE)
    SMAPE = eval.calcSMAPE(testY, testPred)
    print( SMAPE)


    for i in range(len(testY)):
                         
        dataframe1 = pd.DataFrame({'testY':testY[i],'testPred':testPred[i]})
        dataframe1.to_csv(r"./data/MLP.csv", mode = 'a', sep=',')
    
   
#残差子序列预测结果可视化
    plt.figure(figsize=(12, 8))
    plt.xticks(fontsize=22)
    plt.yticks(fontsize=22)
    plt.xlabel(u"Number of Samples", size=28) #x轴标签
    plt.ylabel(" trend subsequence (x10 Mb)",size=28) #Y轴标签  
    plt.plot([x for x in trTrain],c='g', linewidth=3)
    gtruth = np.concatenate((trTrainY,  trTestY))
    plt.plot(gtruth,c='b', linewidth=1)
    plt.plot([None for _ in trTrain]+[x for x in trTest],c='r', linewidth=3)
    plt.show()
    
#残差子序列预测结果可视化
    plt.figure(figsize=(12, 8))
    plt.xticks(fontsize=22)
    plt.yticks(fontsize=22)
    plt.xlabel(u"Number of Samples", size=28) #x轴标签
    plt.ylabel("residual subsequence (x10 Mb)",size=28) #Y轴标签 
    plt.plot([x for x in resTrain],c='g', linewidth=3)
    gtruth = np.concatenate((resTrainY,  resTestY))
    plt.plot(gtruth,c='b', linewidth=1)
    plt.plot([None for _ in resTrain]+[x for x in resTest],c='r', linewidth=3)
    plt.show()
    
    
  #最终预测结果可视化  
    plt.figure(figsize=(12, 8))
    plt.xticks(fontsize=22)
    plt.yticks(fontsize=22)
    plt.xlabel(u"Number of Samples", size=28) #x轴标签
    plt.ylabel("Free Physical Memory (x10 Mb)",size=28) #Y轴标签
    plt.plot([x for x in trainPred],c='g', linewidth=3)
    gtruth = np.concatenate((trainY, testY))
    plt.plot(gtruth,c='b', linewidth=1)
    plt.plot([None for _ in trainPred]+[x for x in testPred],c='r', linewidth=3)
    plt.show()



    return trainPred, testPred, MAE, MRSE, SMAPE


if __name__ == "__main__":

    lag = 24
    batch_size = 32
    epoch = 50
    hidden_dim = 64
    lr = 1e-4
    freq = 18

#####################   1     ##################################
    ts, data = util.load_data("./data/IoTdata1.csv", columnName="Mem")
    
    ts1, trend = util.load_data("./data/18/sub1.csv", columnName="trend")
    ts2, seasonal = util.load_data("./data/18/sub1.csv", columnName="seasonal")
    ts3, residual = util.load_data("./data/18/sub1.csv", columnName="remainder")
   # print (trend)
#######################################################################

    trainPred, testPred, mae, mrse, smape = decompose_MLP_forecasting(ts, ts1, ts2, ts3, data, trend, seasonal, residual, lag=lag, freq=freq,
                                                                      epoch=epoch, hidden_num=hidden_dim,
                                                                      lr=lr, batch_size=batch_size)
